﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13
{
    class Program
    {
        static void Main(string[] args)
        {
            //for (int k = 10; k <=15 ; )
            //{
            //    Console.WriteLine(k);
            //    k++;
            //}
            //int i=1;
            //Console.ForegroundColor = ConsoleColor.Cyan;
            //for (; i<=10 ; i++)
            //{
            //    Console.WriteLine("Iran");
            //    i++;
            //}
            Console.ForegroundColor = ConsoleColor.Cyan;
            for (;;)
            {
                Console.WriteLine("Iran");
            }

            Console.ReadKey();
        }
    }
}
