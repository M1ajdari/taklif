﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mmad3
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <=20; i++)
            {
                Console.WriteLine(i);

            }
            Console.ReadKey();
        }
    }
}
