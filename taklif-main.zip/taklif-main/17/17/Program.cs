﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _17
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 99;
            while (i>=1)
            {
                Console.WriteLine(--i);
            }
            Console.ReadLine();
        }
    }
}
