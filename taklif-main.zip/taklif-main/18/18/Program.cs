﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _18
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 100;
            while (i<=1000)
            {
                Console.WriteLine(++i);
            }
            Console.ReadLine();
        }
    }
}
